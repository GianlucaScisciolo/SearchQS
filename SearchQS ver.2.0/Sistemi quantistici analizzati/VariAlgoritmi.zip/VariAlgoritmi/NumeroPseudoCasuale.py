import random

# Genera un numero intero pseudo-casuale tra 0 e 31
numero = random.randint(0, 31)
print("Numero pseudo-casuale: ", numero)

