from abc import ABC, abstractmethod

class IResultDynamicAnalysisDAO(ABC):
    
    # Create

    @abstractmethod
    def create(self, rda):
        """ """

    # Read

    @abstractmethod
    def read_by_id_result(self, id_r):
        """ """
    
    # Update

    # Delete









