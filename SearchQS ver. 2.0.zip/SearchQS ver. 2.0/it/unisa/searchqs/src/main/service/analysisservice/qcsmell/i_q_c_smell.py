from abc import ABC, abstractmethod

class IQCSmell(ABC):
    @abstractmethod
    def get_result(self, obj):
        """ """









