frase = "Hello, World!"
frase_clonata = frase
print(f"Frase da clonare: {frase}")
print(f"Frase clonata: {frase_clonata}")

